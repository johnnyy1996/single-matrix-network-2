// SIngleMatrixNetwork.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Network.h"
#include <math.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
	//etwork khepera("Ian_Test_Network_Changing_Inputs.txt"); //Ian_Test_Network_Equal_Vary_Inputs.txt
	//Network xor(2, 2, 1, "xor.txt");
	Network xor("xor.txt");

	int i = 0;
	double input[2];
	while (i < 100) {

		input[0] = 0;
		input[1] = 1;
		xor.setNetworkInput(input);
		//xor.squashingFunction(1, 1, -2, 0);
		xor.cycleNetwork();
		xor.writeNetworkSquashedOutputStateToFile("xorOUTPUTSquashed2.txt");
		xor.printNetworkOutputState();
		xor.writeNetworkOutputStateToFile("xor_out.txt");

		i++;
	}
	
	return 0;

}
